package ru.neoflex.users.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Person {

  @JsonProperty("LastName")
  private String lastName;

  @JsonProperty("FirstName")
  private String firstName;

  @JsonProperty("Patronymic")
  private String patronymic;

  @JsonFormat(pattern = "yyyy-MM-dd", timezone = "Europe/Moscow")
  @JsonProperty("BirthDate")
  private Date birthDate;

  @JsonProperty("Gender")
  private Integer gender;

  @JsonProperty("Income")
  private Double income;
}
