package ru.neoflex.users.service;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.neoflex.users.model.CalcAvailableLimitRq;
import ru.neoflex.users.model.CalcAvailableLimitRs;
import ru.neoflex.users.model.Control;
import ru.neoflex.users.model.Output;

@Service
@Slf4j
public class ClientService {

  @Value("${borderAge}")
  private Integer borderAge;

  @Value("${borderAfter}")
  private Double borderAfter;

  @Value("${limitBefore}")
  private Double limitBefore;

  public CalcAvailableLimitRs getRs(CalcAvailableLimitRq calcAvailableLimitRq) {

    CalcAvailableLimitRs rs = new CalcAvailableLimitRs();

    BeanUtils.copyProperties(calcAvailableLimitRq, rs);
    rs.setOutput(new Output());
    rs.setControl(new Control());

    calAvailableLimit(rs);

    log.info("Response model: {}", rs);
    return rs;
  }

  private Integer calcAge(Date birthDateToCalc) {

    LocalDate birthDate = birthDateToCalc.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    Period age = Period.between(birthDate, LocalDate.now());

    return age.getYears();

  }

  private void calAvailableLimit(CalcAvailableLimitRs rs) {

    try {
      Integer age = calcAge(rs.getPerson().getBirthDate());
      Double income = rs.getPerson().getIncome();

      if (age >= borderAge) {
        if (income >= borderAfter) {

          rs.getOutput().setApprovedLimit(income / 2);
        } else {

          rs.getOutput().setApprovedLimit(0.0);
        }
      } else {

        if (income >= limitBefore) {

          rs.getOutput().setApprovedLimit(income);
        } else {

          rs.getOutput().setApprovedLimit(limitBefore);
        }
      }
      rs.getControl().setErrorCode(0);
    } catch (Exception ex) {

      rs.getControl().setErrorCode(101);
      rs.getControl().setErrorMsg(ex.toString());
    }

  }

}
