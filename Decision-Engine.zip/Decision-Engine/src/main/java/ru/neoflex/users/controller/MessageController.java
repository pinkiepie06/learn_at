package ru.neoflex.users.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.neoflex.users.model.CalcAvailableLimitRq;
import ru.neoflex.users.model.CalcAvailableLimitRs;
import ru.neoflex.users.service.ClientService;


@Slf4j
@RestController
@RequestMapping("/v1/decision-engine")
@RequiredArgsConstructor
public class MessageController {

  private final ClientService clientService;

  @PostMapping("calcAvailableLimit")
  public CalcAvailableLimitRs create(@RequestBody CalcAvailableLimitRq calcAvailableLimitRq) {

    log.info("requested model = {}", calcAvailableLimitRq);
    return clientService.getRs(calcAvailableLimitRq);
  }

}
